/**
 * Homework 11
 * This program uses the interface
 * @author Ley Yen Choo, lab sec 01
 * @version February, 25 2016
 */
public class Superman implements AlterEgo, Superhero {

    @Override
    public void writeNewspaperArticle() {
    }
    @Override
    public void fly() {
    }

}

