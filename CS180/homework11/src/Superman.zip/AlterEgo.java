/**
 * Created by LeyYen on 2/23/2016.
 */
public interface AlterEgo {
    public void writeNewspaperArticle();

}