/**
 * Created by LeyYen on 3/31/2016.
 */
public class MalformedQueryException extends Exception {

    public MalformedQueryException(String message) {
        super(message);
    }

    public MalformedQueryException() {
        super();
    }
}
