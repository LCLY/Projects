/**
 * Created by LeyYen on 3/31/2016.
 */
public class WrongNumberOfQueriesException extends Exception {

    public WrongNumberOfQueriesException(String message) {
        super(message);
    }

    public WrongNumberOfQueriesException() {
        super();
    }

}
