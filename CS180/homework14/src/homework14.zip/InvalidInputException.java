/**
 * Created by LeyYen on 3/31/2016.
 */
public class InvalidInputException extends Exception {

    public InvalidInputException(String message) {
        super(message);
    }

    public InvalidInputException() {
        super();
    }

}
