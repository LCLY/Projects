/**
 * Created by LeyYen on 3/31/2016.
 */
public class WrongFileFormatException extends Exception {
    String[] array = null;

    public WrongFileFormatException(String message) {
        super(message);
    }

    public WrongFileFormatException() {
        super();
    }

}
