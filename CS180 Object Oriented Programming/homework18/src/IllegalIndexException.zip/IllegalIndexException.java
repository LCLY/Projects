public class IllegalIndexException extends Exception {
    
    public IllegalIndexException () {
        super("Wrong provided Indices");
    }
    
}
